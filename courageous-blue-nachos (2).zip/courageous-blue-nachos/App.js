import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  TextInput,
  SafeAreaView,
  StatusBar,
  Dimensions,
  I18nManager,
  Animated,
  Easing
} from 'react-native';

const { width } = Dimensions.get('window');

// ==========================================
// 1. DICTIONARY & LOCALIZATION (AR / EN)
// ==========================================
const translations = {
  ar: {
    appName: "وصلة",
    tagline: "منصة تنقل الموظفين في دبي",
    loginTitle: "مرحباً بك مجدداً",
    loginSub: "تسجيل الدخول لإدارة رحلاتك اليومية",
    phonePlaceholder: "رقم الهاتف (05xxxxxxxx)",
    passPlaceholder: "كلمة المرور",
    loginBtn: "تسجيل الدخول",
    toggleLang: "English",
    planTitle: "خطط لأسبوعك",
    planSub: "اختر أيام التنقل والمواقف والمواعيد",
    activeDays: "أيام العمل النشطة",
    routeLabel: "المسار المفضّل",
    pickupLabel: "نقطة الركوب (Satwa/Bur Dubai)",
    dropoffLabel: "نقطة النزول (Business Bay/Marina)",
    timeLabel: "توقيت الانطلاق",
    subLabel: "باقة الاشتراك",
    weeklyPass: "اشتراك أسبوعي",
    monthlyPass: "اشتراك شهري",
    tabbyOption: "قسّمها على 4 دفعات مع Tabby (0% فائدة)",
    confirmPlanBtn: "تأكيد الباقة والتكلفة",
    seatTitle: "اختيار المقعد",
    seatSub: "اختر مكانك المفضّل داخل الحافلة",
    front: "المقدمة (السائق)",
    confirmSeat: "تأكيد المقعد والمتابعة",
    ticketTitle: "تذكرة الصعود",
    ticketSub: "امسح رمز QR عند الصعود للحافلة",
    seatNum: "المقعد الرقم:",
    depTime: "الوقت:",
    route: "المسار:",
    trackBusBtn: "تتبع الحافلة مباشرة",
    trackerTitle: "التتبع الحي للحافلة",
    trackerSub: "حافلة DXB-A-45821 · متجهة لنقطة النزول",
    eta: "الوقت المتوقع للوصول",
    minutes: "دقائق",
    backToHome: "العودة للرئيسية",
    satwa: "السطوة",
    karama: "الكرامة",
    burDubai: "بر دبي",
    marina: "مرسى دبي (المارينا)",
    businessBay: "الخليج التجاري",
    selectSeatsFirst: "يرجى اختيار مقعد",
    currPrice: "الإجمالي: "
  },
  en: {
    appName: "Wasla",
    tagline: "Dubai Commuter Transit Platform",
    loginTitle: "Welcome Back",
    loginSub: "Log in to manage your daily commutes",
    phonePlaceholder: "Phone Number (05xxxxxxxx)",
    passPlaceholder: "Password",
    loginBtn: "Log In",
    toggleLang: "عربي",
    planTitle: "Plan Your Week",
    planSub: "Select active workdays, stops and schedule",
    activeDays: "Active Workdays",
    routeLabel: "Preferred Route",
    pickupLabel: "Pickup Hotspot",
    dropoffLabel: "Drop-off Hotspot",
    timeLabel: "Departure Time",
    subLabel: "Subscription Plan",
    weeklyPass: "Weekly Pass",
    monthlyPass: "Monthly Pass",
    tabbyOption: "Split in 4 payments with Tabby (0% interest)",
    confirmPlanBtn: "Confirm Plan & Proceed",
    seatTitle: "Select Seat",
    seatSub: "Choose your preferred seat on the bus",
    front: "Front (Driver)",
    confirmSeat: "Confirm Seat & Proceed",
    ticketTitle: "Boarding Pass",
    ticketSub: "Scan QR code upon boarding",
    seatNum: "Seat Number:",
    depTime: "Departure:",
    route: "Route:",
    trackBusBtn: "Live Track Bus",
    trackerTitle: "Live Fleet Tracker",
    trackerSub: "Bus DXB-A-45821 · En route to drop-off",
    eta: "Estimated Arrival",
    minutes: "mins",
    backToHome: "Back to Home",
    satwa: "Satwa",
    karama: "Karama",
    burDubai: "Bur Dubai",
    marina: "Dubai Marina",
    businessBay: "Business Bay",
    selectSeatsFirst: "Please select a seat",
    currPrice: "Total: "
  }
};

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
const TIMES = ['07:00 AM', '07:45 AM', '08:30 AM'];

// ==========================================
// 2. MAIN APP COMPONENT
// ==========================================
export default function App() {
  const [lang, setLang] = useState('ar');
  const t = translations[lang];

  // Screen state navigation: 'LOGIN' | 'PLAN' | 'SEAT' | 'TICKET' | 'TRACKER'
  const [screen, setScreen] = useState('LOGIN');

  // Booking Data States
  const [selectedDays, setSelectedDays] = useState(['Mon', 'Tue', 'Wed', 'Thu']);
  const [selectedRoute, setSelectedRoute] = useState(1);
  const [pickup, setPickup] = useState('Satwa');
  const [dropoff, setDropoff] = useState('Dubai Marina');
  const [selectedTime, setSelectedTime] = useState('07:45 AM');
  const [subTier, setSubTier] = useState('monthly'); // 'weekly' | 'monthly'
  const [tabby, setTabby] = useState(true);
  const [selectedSeat, setSelectedSeat] = useState(null);

  // Animation for Live Bus Tracking
  const [busProgress] = useState(new Animated.Value(0));

  useEffect(() => {
    if (screen === 'TRACKER') {
      busProgress.setValue(0);
      Animated.loop(
        Animated.timing(busProgress, {
          toValue: 1,
          duration: 8000,
          easing: Easing.linear,
          useNativeDriver: false,
        })
      ).start();
    }
  }, [screen]);

  const toggleLanguage = () => {
    setLang(prev => (prev === 'ar' ? 'en' : 'ar'));
  };

  const toggleDay = (day) => {
    if (selectedDays.includes(day)) {
      setSelectedDays(selectedDays.filter(d => d !== day));
    } else {
      setSelectedDays([...selectedDays, day]);
    }
  };

  // Calculate Price Dynamic
  const price = subTier === 'monthly' ? 420 : 130;

  // Real-time seats setup (12 Seats grid)
  const seatsList = Array.from({ length: 12 }, (_, i) => ({
    id: i + 1,
    booked: i === 2 || i === 7, // mock taken seats
  }));

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0B1120" />

      {/* HEADER TOP BAR */}
      <View style={[styles.header, { flexDirection: lang === 'ar' ? 'row-reverse' : 'row' }]}>
        <Text style={styles.logoText}>{t.appName}</Text>
        <TouchableOpacity style={styles.langBtn} onPress={toggleLanguage}>
          <Text style={styles.langBtnText}>{t.toggleLang}</Text>
        </TouchableOpacity>
      </View>

      {/* =================================================== */}
      {/* SCREEN 1: LOGIN                                     */}
      {/* =================================================== */}
      {screen === 'LOGIN' && (
        <ScrollView contentContainerStyle={styles.scrollBody}>
          <View style={styles.authBox}>
            <View style={styles.badge}>
              <Text style={styles.badgeText}>DUBAI FLEET SERVICES</Text>
            </View>
            <Text style={styles.title}>{t.loginTitle}</Text>
            <Text style={styles.subtitle}>{t.loginSub}</Text>

            <TextInput
              style={[styles.input, { textAlign: lang === 'ar' ? 'right' : 'left' }]}
              placeholder={t.phonePlaceholder}
              placeholderTextColor="#8B94A8"
              keyboardType="phone-pad"
            />
            <TextInput
              style={[styles.input, { textAlign: lang === 'ar' ? 'right' : 'left' }]}
              placeholder={t.passPlaceholder}
              placeholderTextColor="#8B94A8"
              secureTextEntry
            />

            <TouchableOpacity style={styles.primaryBtn} onPress={() => setScreen('PLAN')}>
              <Text style={styles.primaryBtnText}>{t.loginBtn}</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      )}

      {/* =================================================== */}
      {/* SCREEN 2: ROUTE & SCHEDULING PLAN                   */}
      {/* =================================================== */}
      {screen === 'PLAN' && (
        <ScrollView contentContainerStyle={styles.scrollBody}>
          <Text style={[styles.title, { textAlign: lang === 'ar' ? 'right' : 'left' }]}>{t.planTitle}</Text>
          <Text style={[styles.subtitle, { textAlign: lang === 'ar' ? 'right' : 'left' }]}>{t.planSub}</Text>

          {/* ACTIVE DAYS */}
          <Text style={[styles.label, { textAlign: lang === 'ar' ? 'right' : 'left' }]}>{t.activeDays}</Text>
          <View style={styles.rowPills}>
            {DAYS.map(day => (
              <TouchableOpacity
                key={day}
                style={[styles.dayPill, selectedDays.includes(day) && styles.activePill]}
                onPress={() => toggleDay(day)}
              >
                <Text style={[styles.pillText, selectedDays.includes(day) && styles.activePillText]}>{day}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* ROUTE OPTIONS */}
          <Text style={[styles.label, { textAlign: lang === 'ar' ? 'right' : 'left' }]}>{t.routeLabel}</Text>
          <TouchableOpacity
            style={[styles.card, selectedRoute === 1 && styles.cardSelected]}
            onPress={() => setSelectedRoute(1)}
          >
            <Text style={styles.cardTitle}>Route 1: Satwa ➔ Dubai Marina</Text>
            <Text style={styles.cardSub}>Express Commute via Sheikh Zayed Rd</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.card, selectedRoute === 2 && styles.cardSelected]}
            onPress={() => setSelectedRoute(2)}
          >
            <Text style={styles.cardTitle}>Route 2: Bur Dubai ➔ Business Bay</Text>
            <Text style={styles.cardSub}>City Center Direct Corridor</Text>
          </TouchableOpacity>

          {/* DEPARTURE TIME */}
          <Text style={[styles.label, { textAlign: lang === 'ar' ? 'right' : 'left' }]}>{t.timeLabel}</Text>
          <View style={styles.rowPills}>
            {TIMES.map(tm => (
              <TouchableOpacity
                key={tm}
                style={[styles.pill, selectedTime === tm && styles.activePill]}
                onPress={() => setSelectedTime(tm)}
              >
                <Text style={[styles.pillText, selectedTime === tm && styles.activePillText]}>{tm}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* SUBSCRIPTION TOGGLE */}
          <Text style={[styles.label, { textAlign: lang === 'ar' ? 'right' : 'left' }]}>{t.subLabel}</Text>
          <View style={styles.toggleContainer}>
            <TouchableOpacity
              style={[styles.toggleBtn, subTier === 'weekly' && styles.toggleBtnActive]}
              onPress={() => setSubTier('weekly')}
            >
              <Text style={[styles.toggleBtnText, subTier === 'weekly' && styles.toggleBtnTextActive]}>{t.weeklyPass}</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.toggleBtn, subTier === 'monthly' && styles.toggleBtnActive]}
              onPress={() => setSubTier('monthly')}
            >
              <Text style={[styles.toggleBtnText, subTier === 'monthly' && styles.toggleBtnTextActive]}>{t.monthlyPass}</Text>
            </TouchableOpacity>
          </View>

          {/* TABBY PAYMENT INTEGRATION */}
          <TouchableOpacity style={styles.checkboxRow} onPress={() => setTabby(!tabby)}>
            <View style={[styles.checkbox, tabby && styles.checkboxOn]}>
              {tabby && <Text style={styles.checkIcon}>✓</Text>}
            </View>
            <Text style={styles.checkText}>{t.tabbyOption}</Text>
          </TouchableOpacity>

          {/* CONFIRM CTA */}
          <TouchableOpacity style={styles.primaryBtn} onPress={() => setScreen('SEAT')}>
            <Text style={styles.primaryBtnText}>
              {t.confirmPlanBtn} · AED {price}
            </Text>
          </TouchableOpacity>
        </ScrollView>
      )}

      {/* =================================================== */}
      {/* SCREEN 3: SEAT SELECTION                            */}
      {/* =================================================== */}
      {screen === 'SEAT' && (
        <ScrollView contentContainerStyle={styles.scrollBody}>
          <Text style={[styles.title, { textAlign: lang === 'ar' ? 'right' : 'left' }]}>{t.seatTitle}</Text>
          <Text style={[styles.subtitle, { textAlign: lang === 'ar' ? 'right' : 'left' }]}>{t.seatSub}</Text>

          {/* BUS LAYOUT */}
          <View style={styles.busLayout}>
            <View style={styles.driverSection}>
              <Text style={styles.driverText}>🚌 {t.front}</Text>
            </View>

            <View style={styles.seatsGrid}>
              {seatsList.map(seat => {
                const isSelected = selectedSeat === seat.id;
                return (
                  <TouchableOpacity
                    key={seat.id}
                    disabled={seat.booked}
                    style={[
                      styles.seatBox,
                      seat.booked && styles.seatBooked,
                      isSelected && styles.seatSelected,
                    ]}
                    onPress={() => setSelectedSeat(seat.id)}
                  >
                    <Text style={[styles.seatText, isSelected && styles.seatTextSelected]}>
                      {seat.booked ? 'X' : seat.id}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>

          <TouchableOpacity
            style={[styles.primaryBtn, !selectedSeat && { opacity: 0.5 }]}
            disabled={!selectedSeat}
            onPress={() => setScreen('TICKET')}
          >
            <Text style={styles.primaryBtnText}>
              {selectedSeat ? t.confirmSeat : t.selectSeatsFirst}
            </Text>
          </TouchableOpacity>
        </ScrollView>
      )}

      {/* =================================================== */}
      {/* SCREEN 4: BOARDING PASS (TICKET)                    */}
      {/* =================================================== */}
      {screen === 'TICKET' && (
        <ScrollView contentContainerStyle={styles.scrollBody}>
          <View style={styles.ticketCard}>
            <Text style={styles.ticketHeader}>{t.ticketTitle}</Text>
            <Text style={styles.ticketSub}>{t.ticketSub}</Text>

            {/* Simulated QR Code Visual */}
            <View style={styles.qrCodeBox}>
              <View style={styles.qrMockRow}>
                <View style={styles.qrSquare} />
                <View style={[styles.qrSquare, { backgroundColor: '#0B1120' }]} />
                <View style={styles.qrSquare} />
              </View>
              <View style={styles.qrMockRow}>
                <View style={[styles.qrSquare, { backgroundColor: '#0B1120' }]} />
                <View style={styles.qrSquare} />
                <View style={[styles.qrSquare, { backgroundColor: '#0B1120' }]} />
              </View>
              <View style={styles.qrMockRow}>
                <View style={styles.qrSquare} />
                <View style={[styles.qrSquare, { backgroundColor: '#0B1120' }]} />
                <View style={styles.qrSquare} />
              </View>
            </View>

            <View style={styles.ticketInfoGroup}>
              <Text style={styles.infoLine}><Text style={styles.boldLabel}>{t.seatNum}</Text> #{selectedSeat}</Text>
              <Text style={styles.infoLine}><Text style={styles.boldLabel}>{t.depTime}</Text> {selectedTime}</Text>
              <Text style={styles.infoLine}><Text style={styles.boldLabel}>{t.route}</Text> Satwa ➔ Marina</Text>
            </View>
          </View>

          <TouchableOpacity style={[styles.primaryBtn, { backgroundColor: '#1FAE7A' }]} onPress={() => setScreen('TRACKER')}>
            <Text style={[styles.primaryBtnText, { color: '#FFFFFF' }]}>{t.trackBusBtn}</Text>
          </TouchableOpacity>
        </ScrollView>
      )}

      {/* =================================================== */}
      {/* SCREEN 5: LIVE FLEET TRACKER                        */}
      {/* =================================================== */}
      {screen === 'TRACKER' && (
        <ScrollView contentContainerStyle={styles.scrollBody}>
          <Text style={[styles.title, { textAlign: lang === 'ar' ? 'right' : 'left' }]}>{t.trackerTitle}</Text>
          <Text style={[styles.subtitle, { textAlign: lang === 'ar' ? 'right' : 'left' }]}>{t.trackerSub}</Text>

          {/* Interactive Map Track Container */}
          <View style={styles.mapCanvas}>
            <View style={styles.mapGridLine} />
            <View style={styles.mapTrackPath} />

            {/* Moving Bus Pin */}
            <Animated.View
              style={[
                styles.busMarker,
                {
                  left: busProgress.interpolate({
                    inputRange: [0, 1],
                    outputRange: ['5%', '85%'],
                  }),
                },
              ]}
            >
              <Text style={{ fontSize: 16 }}>🚌</Text>
            </Animated.View>

            <View style={[styles.stopPin, { left: '5%' }]}>
              <Text style={styles.stopPinText}>Satwa</Text>
            </View>
            <View style={[styles.stopPin, { left: '85%', backgroundColor: '#1FAE7A' }]}>
              <Text style={styles.stopPinText}>Marina</Text>
            </View>
          </View>

          {/* ETA Display Card */}
          <View style={styles.etaCard}>
            <Text style={styles.etaLabel}>{t.eta}</Text>
            <Text style={styles.etaValue}>12 <Text style={{ fontSize: 16, color: '#8B94A8' }}>{t.minutes}</Text></Text>
          </View>

          <TouchableOpacity style={[styles.primaryBtn, { marginTop: 20 }]} onPress={() => setScreen('PLAN')}>
            <Text style={styles.primaryBtnText}>{t.backToHome}</Text>
          </TouchableOpacity>
        </ScrollView>
      )}

    </SafeAreaView>
  );
}

// ==========================================
// 3. STYLES (REACT NATIVE DESIGN SYSTEM)
// ==========================================
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0B1120',
  },
  header: {
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(245,243,238,0.08)',
  },
  logoText: {
    color: '#E8A33D',
    fontSize: 22,
    fontWeight: 'bold',
  },
  langBtn: {
    backgroundColor: '#182238',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(245,243,238,0.16)',
  },
  langBtnText: {
    color: '#F5F3EE',
    fontSize: 12,
    fontWeight: '600',
  },
  scrollBody: {
    padding: 20,
  },
  authBox: {
    marginTop: 40,
    alignItems: 'center',
  },
  badge: {
    backgroundColor: 'rgba(232,163,61,0.1)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    marginBottom: 15,
  },
  badgeText: {
    color: '#E8A33D',
    fontSize: 10,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  title: {
    color: '#F5F3EE',
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 6,
  },
  subtitle: {
    color: '#8B94A8',
    fontSize: 14,
    marginBottom: 25,
  },
  label: {
    color: '#8B94A8',
    fontSize: 12,
    fontWeight: 'bold',
    textTransform: 'uppercase',
    marginTop: 20,
    marginBottom: 10,
  },
  input: {
    width: '100%',
    backgroundColor: '#121A2E',
    borderWidth: 1,
    borderColor: 'rgba(245,243,238,0.08)',
    borderRadius: 12,
    padding: 15,
    color: '#F5F3EE',
    fontSize: 14,
    marginBottom: 15,
  },
  primaryBtn: {
    width: '100%',
    backgroundColor: '#E8A33D',
    borderRadius: 14,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 20,
    elevation: 3,
  },
  primaryBtnText: {
    color: '#1A1305',
    fontWeight: 'bold',
    fontSize: 15,
  },
  rowPills: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  dayPill: {
    width: 45,
    height: 45,
    borderRadius: 12,
    backgroundColor: '#182238',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(245,243,238,0.08)',
  },
  pill: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: '#182238',
    borderWidth: 1,
    borderColor: 'rgba(245,243,238,0.08)',
  },
  activePill: {
    backgroundColor: '#E8A33D',
    borderColor: '#E8A33D',
  },
  pillText: {
    color: '#8B94A8',
    fontWeight: '600',
    fontSize: 13,
  },
  activePillText: {
    color: '#1A1305',
  },
  card: {
    backgroundColor: '#121A2E',
    borderRadius: 14,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(245,243,238,0.08)',
    marginBottom: 10,
  },
  cardSelected: {
    borderColor: '#E8A33D',
    backgroundColor: 'rgba(232,163,61,0.05)',
  },
  cardTitle: {
    color: '#F5F3EE',
    fontWeight: 'bold',
    fontSize: 15,
  },
  cardSub: {
    color: '#8B94A8',
    fontSize: 12,
    marginTop: 4,
  },
  toggleContainer: {
    flexDirection: 'row',
    backgroundColor: '#182238',
    borderRadius: 12,
    padding: 4,
  },
  toggleBtn: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 8,
  },
  toggleBtnActive: {
    backgroundColor: '#12332A',
    borderWidth: 1,
    borderColor: '#1FAE7A',
  },
  toggleBtnText: {
    color: '#8B94A8',
    fontWeight: '600',
    fontSize: 13,
  },
  toggleBtnTextActive: {
    color: '#1FAE7A',
  },
  checkboxRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 20,
    backgroundColor: '#182238',
    padding: 12,
    borderRadius: 12,
  },
  checkbox: {
    width: 20,
    height: 20,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: '#8B94A8',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  checkboxOn: {
    backgroundColor: '#E8A33D',
    borderColor: '#E8A33D',
  },
  checkIcon: {
    color: '#1A1305',
    fontWeight: 'bold',
    fontSize: 12,
  },
  checkText: {
    color: '#8B94A8',
    fontSize: 12,
    flex: 1,
  },
  busLayout: {
    backgroundColor: '#121A2E',
    borderRadius: 20,
    padding: 20,
    marginVertical: 15,
    borderWidth: 1,
    borderColor: 'rgba(245,243,238,0.08)',
  },
  driverSection: {
    paddingBottom: 15,
    marginBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(245,243,238,0.08)',
    alignItems: 'center',
  },
  driverText: {
    color: '#8B94A8',
    fontSize: 12,
  },
  seatsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 12,
  },
  seatBox: {
    width: (width - 110) / 4,
    height: 45,
    backgroundColor: '#182238',
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(245,243,238,0.08)',
  },
  seatBooked: {
    backgroundColor: '#E5605F',
    opacity: 0.3,
  },
  seatSelected: {
    backgroundColor: '#1FAE7A',
    borderColor: '#1FAE7A',
  },
  seatText: {
    color: '#F5F3EE',
    fontWeight: 'bold',
  },
  seatTextSelected: {
    color: '#FFFFFF',
  },
  ticketCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    marginVertical: 20,
  },
  ticketHeader: {
    color: '#0B1120',
    fontSize: 20,
    fontWeight: 'bold',
  },
  ticketSub: {
    color: '#5B6478',
    fontSize: 12,
    marginTop: 4,
  },
  qrCodeBox: {
    width: 140,
    height: 140,
    backgroundColor: '#F5F3EE',
    marginVertical: 20,
    padding: 10,
    justifyContent: 'space-around',
  },
  qrMockRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  qrSquare: {
    width: 30,
    height: 30,
    backgroundColor: '#1FAE7A',
  },
  ticketInfoGroup: {
    width: '100%',
    borderTopWidth: 1,
    borderTopColor: '#EEEEEE',
    paddingTop: 15,
  },
  infoLine: {
    color: '#0B1120',
    fontSize: 14,
    marginBottom: 6,
  },
  boldLabel: {
    fontWeight: 'bold',
  },
  mapCanvas: {
    height: 200,
    backgroundColor: '#121A2E',
    borderRadius: 20,
    marginVertical: 15,
    position: 'relative',
    justifyContent: 'center',
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(245,243,238,0.08)',
  },
  mapGridLine: {
    position: 'absolute',
    width: '100%',
    height: 1,
    backgroundColor: 'rgba(245,243,238,0.05)',
  },
  mapTrackPath: {
    height: 4,
    backgroundColor: '#E8A33D',
    width: '80%',
    alignSelf: 'center',
  },
  busMarker: {
    position: 'absolute',
    top: '40%',
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#E8A33D',
    justifyContent: 'center',
    alignItems: 'center',
  },
  stopPin: {
    position: 'absolute',
    top: '35%',
    backgroundColor: '#3D7FE0',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  stopPinText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  etaCard: {
    backgroundColor: '#121A2E',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(245,243,238,0.08)',
  },
  etaLabel: {
    color: '#8B94A8',
    fontSize: 12,
  },
  etaValue: {
    color: '#F5F3EE',
    fontSize: 36,
    fontWeight: 'bold',
    marginTop: 5,
  },
});
